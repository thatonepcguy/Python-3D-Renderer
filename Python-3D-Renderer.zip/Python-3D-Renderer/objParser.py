
def parseBasic(objPath, mtlPath, scale, yOffset):
    file = open(f"{mtlPath}")
    colors = []
    names = []
    for line in file:
        if line.startswith("newmtl "):
            parts = line.split()
            names.append(parts[1])
        if line.startswith("\tKd "):
            parts = line.split()
            color = [round(float(parts[1])*255, 0), round(float(parts[2])*255, 0), round(float(parts[3])*255, 0)]
            colors.append(color)
    print(colors)
    print(names)
    
    faces = []
    vertexes = []

    colorIndexed = []

    FILE = open(f"{objPath}")
    currentMaterial = ""
    for line in FILE:
        # VERTEXES
        if line.startswith("v "):
            parts = line.split()
            if len(parts) == 4:
                x_str, y_str, z_str = parts[1], parts[2], parts[3]
                vertexes.append([round(float(x_str)*scale,2), round(float(y_str)*-scale,5)+yOffset, round(float(z_str)*scale,2)])

        # FACES
        if line.startswith("f "):
            parts = line.split()
            if len(parts) == 4:
                point1, point2, point3= parts[1], parts[2], parts[3]
                point1 = point1.split("/")[0]
                point2 = point2.split("/")[0]
                point3 = point3.split("/")[0]
                faces.append([vertexes[int(point1)-1], vertexes[int(point2)-1], vertexes[int(point3)-1]])
                
            
            if len(parts) == 5:
                point1, point2, point3, point4= parts[1], parts[2], parts[3], parts[4]
                point1 = point1.split("/")[0]
                point2 = point2.split("/")[0]
                point3 = point3.split("/")[0]
                point4 = point4.split("/")[0]
                faces.append([vertexes[int(point1)-1], vertexes[int(point2)-1], vertexes[int(point3)-1], vertexes[int(point4)-1]])
            colorIndexed.append(colors[names.index(currentMaterial)])
        # COLORS
        if line.startswith("usemtl "):
            parts = line.split()
            currentMaterial = parts[1]
        
        

    FILE.close()
    return faces, colorIndexed