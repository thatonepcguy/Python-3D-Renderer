A basic wireframe 3d renderer i made in python using pygame. It could use some optimization
