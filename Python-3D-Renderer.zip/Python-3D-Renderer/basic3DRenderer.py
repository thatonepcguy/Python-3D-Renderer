import pygame
import numpy as np
from math import cos, sin, radians, sqrt
import objParser as parser

def convert(object, FOV):
    convertedPoints = []
    for triangle in object:
        convertedTriangle = []
        for point in triangle:
            x = float(point[0] * FOV / point[2])
            y = float(point[1] * FOV / point[2])
            convertedTriangle.append((x+640, y+360))
        convertedPoints.append(convertedTriangle)
    return convertedPoints


def render(object2D, normalMap, screen):

    for i, triangle in enumerate(object2D):
        if len(triangle) >= 3:
            normal = normalMap[i]
            color = (
                max(0, min(255, int((normal[0] + 1) * 127.5))),
                max(0, min(255, int((normal[1] + 1) * 127.5))),
                max(0, min(255, int((normal[2] + 1) * 127.5)))
            )
            pygame.draw.polygon(screen, color, triangle)



def transform(cameraPos, object):
    adjustedObject = []
    for triangle in object:
        adjustedTriangle = []
        for point in triangle:
            adjustedPoint = [0,0,0]
            for i in range(3):
                adjustedPoint[i] = point[i]-cameraPos[i]

            adjustedTriangle.append(adjustedPoint)
        adjustedObject.append(adjustedTriangle)
            
    return adjustedObject


def rotate(cameraRot, object, normalMap):
    theta_x = cameraRot[0]
    theta_y = cameraRot[1]
    theta_z = cameraRot[2]

    culledNormal = []

    ROTATION_MATRIX_X = np.matrix([[1,      0,              0     ], 
                                   [0, cos(theta_x), -sin(theta_x)],
                                   [0, sin(theta_x), cos(theta_x)]])
    ROTATION_MATRIX_Y = np.matrix([[cos(theta_y), 0, sin(theta_y)],
                                  [0, 1, 0],
                                  [-sin(theta_y), 0, cos(theta_y)]])
    ROTATION_MATRIX_Z = np.matrix([[cos(theta_z), -sin(theta_z), 0],
                                  [sin(theta_z), cos(theta_z), 0],
                                  [0, 0, 1]])
    rotatedObject = []
    for i, triangle in enumerate(object):
        rotatedTriangle = []
        for point in triangle:
            rotatedPoint = np.matrix([[point[0]], [point[1]], [point[2]]])
            rotatedPoint = np.dot(ROTATION_MATRIX_Y, rotatedPoint)
            rotatedPoint = np.dot(ROTATION_MATRIX_X, rotatedPoint)
            rotatedPoint = np.dot(ROTATION_MATRIX_Z, rotatedPoint)
            rotatedTriangle.append(rotatedPoint)
        if all(rotatedTriangle[i][2] > 0 for i in range(len(rotatedTriangle))):
            rotatedObject.append(rotatedTriangle)
            culledNormal.append(normalMap[i])

    return rotatedObject, culledNormal


def sortByDistance(object, normalMap):
    faceDistances = []
    for face in object:
        totalDistance = 0
        for point in face:
            totalDistance += sqrt(sum(point[i]**2 for i in range(len(point))))
        
        if len(face) != 0:
            avgDistance = totalDistance / len(face)
            faceDistances.append(avgDistance)
    return [x for _, x in sorted(zip(faceDistances, object), key=lambda pair: pair[0], reverse=True)], [x for _, x in sorted(zip(faceDistances, normalMap), key=lambda pair: pair[0], reverse=True)]

def calculateNormal(face):
    face = [np.array(point).flatten() for point in face]
    
    v1 = face[1] - face[0]
    v2 = face[2] - face[0]
    
    normal = np.cross(v1, v2)
    normal = normal / np.linalg.norm(normal)
    
    return normal

def calculateNormalObject(object):
    normalMap = []
    for face in object:
        normal = calculateNormal(face)
        normalMap.append(normal)

    return normalMap

def main():
    WIDTH, HEIGHT = 1280, 720
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()

    cameraPos = [0, 0, -100]
    cameraRot = [0, 0, 0]

    FOV = 100  # Adjust FOV for visible projection
    
    object= parser.parseBasic("Python-3D-Renderer\\monkey.obj", 10, 0)
    objectNormalMap = calculateNormalObject(object)

    pygame.init()

    keysPressed = []

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w:
                    keysPressed.append("w")
                if event.key == pygame.K_s:
                    keysPressed.append("s") 
                if event.key == pygame.K_a:
                    keysPressed.append("a")
                if event.key == pygame.K_d:
                    keysPressed.append("d")
                if event.key == pygame.K_LEFT:
                    keysPressed.append("left")
                if event.key == pygame.K_RIGHT:
                    keysPressed.append("right")
                if event.key == pygame.K_UP:
                    keysPressed.append("up")
                if event.key == pygame.K_DOWN:
                    keysPressed.append("down")
                if event.key == pygame.K_SPACE:
                    keysPressed.append("space")
                if event.key == pygame.K_LSHIFT:
                    keysPressed.append("shift")
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_w:
                    keysPressed.remove("w")
                if event.key == pygame.K_s:
                    keysPressed.remove("s")
                if event.key == pygame.K_a:
                    keysPressed.remove("a")
                if event.key == pygame.K_d:
                    keysPressed.remove("d")
                if event.key == pygame.K_LEFT:
                    keysPressed.remove("left")
                if event.key == pygame.K_RIGHT:
                    keysPressed.remove("right")
                if event.key == pygame.K_UP:
                    keysPressed.remove("up")
                if event.key == pygame.K_DOWN:
                    keysPressed.remove("down")
                if event.key == pygame.K_SPACE:
                    keysPressed.remove("space")
                if event.key == pygame.K_LSHIFT:
                    keysPressed.remove("shift")


        for key in keysPressed:
            if key == "w":
                cameraPos[0] -= 10*sin(cameraRot[1])
                cameraPos[2] += 10*cos(cameraRot[1])
            elif key == "s":
                cameraPos[0] += 10*sin(cameraRot[1])
                cameraPos[2] -= 10*cos(cameraRot[1])
            if key == "a":
                cameraPos[0] -= 10*cos(cameraRot[1])
                cameraPos[2] -= 10*sin(cameraRot[1])
            elif key == "d":
                cameraPos[0] += 10*cos(cameraRot[1])
                cameraPos[2] += 10*sin(cameraRot[1])
            if key == "left":
                cameraRot[1] -= -radians(3)
            elif key == "right":
                cameraRot[1] += -radians(3)
            if key == "up":
                cameraRot[0] += -radians(3)
            elif key == "down":
                cameraRot[0] -= -radians(3)
            if key == "space":
                cameraPos[1] -= 10
            elif key == "shift":
                cameraPos[1] += 10

        objectTransformed = transform(cameraPos, object)
        objectRotated, culledNormal = rotate(cameraRot, objectTransformed, objectNormalMap)
        objectSorted, objectNormalMapSorted = sortByDistance(objectRotated, culledNormal)
        
        objectRendered = convert(objectSorted, FOV)

        screen.fill("black")

        render(objectRendered, objectNormalMapSorted, screen)

        pygame.display.flip()
        clock.tick(60)

if __name__ == "__main__":
    main()
